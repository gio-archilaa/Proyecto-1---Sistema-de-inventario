# Sistema de Gestión de Inventario

Aplicación de consola para una pequeña empresa, desarrollada con Python, SQLite y programación orientada a objetos. Incluye categorías, catálogo de productos, Kardex transaccional, búsquedas, alertas, valorización y exportación a CSV/XLSX.

## Características y decisiones de diseño

- **Capas:** `models` (entidades), `repositories` (SQL parametrizado), `services` (validaciones y reglas), `database` (conexión/transacciones), `utils` (exportación) y `main` (interfaz).
- **Integridad:** claves foráneas activadas en cada conexión, restricciones `CHECK`, SKU único y consultas parametrizadas.
- **Kardex atómico:** cada movimiento utiliza `BEGIN IMMEDIATE`; el registro del movimiento y la actualización de existencias se confirman juntos o se revierten juntos.
- **Trazabilidad:** los productos se desactivan lógicamente. El stock no se edita directamente: se modifica únicamente mediante entradas y salidas.
- **Valorización:** costo del inventario = `precio_compra × stock`; valor potencial de venta = `precio_venta × stock`.

## Requisitos

- Python 3.10 o posterior.
- Git.

## Instalación y ejecución

```bash
git clone <URL-DE-TU-REPOSITORIO>
cd sistema-inventario
python -m venv .venv
# Windows PowerShell: .venv\Scripts\Activate.ps1
# macOS/Linux: source .venv/bin/activate
python -m pip install -r requirements.txt
python -m src.main
```

La base `src/database/inventario.db` y la carpeta de exportaciones se crean/usan localmente; no se versionan.

## Flujo recomendado de uso

1. Crea una categoría (opción 1).
2. Registra un producto (opción 3). Puedes ingresar un stock inicial; el sistema lo registra como movimiento de entrada “Inventario inicial”.
3. Registra compras/reposiciones con **ENTRADA** y ventas/mermas con **SALIDA** (opción 7). Una salida superior al stock disponible se rechaza sin guardar cambios.
4. Consulta productos, inventario valorizado, alertas `stock <= stock mínimo` y Kardex.
5. Exporta tres CSV y un libro Excel de varias hojas (opción 11) a `exports/`.

Los precios se interpretan en la moneda que defina la empresa; la aplicación no impone una moneda ni impuestos.

## Pruebas

```bash
python -m unittest discover -s tests -v
```

Las pruebas emplean una base temporal, no alteran la base de trabajo y verifican movimientos, rollback por stock insuficiente, SKU duplicado, alertas y baja lógica.

## Estructura

```text
sistema-inventario/
├── src/
│   ├── database/connection.py
│   ├── models/entities.py
│   ├── repositories/inventory_repository.py
│   ├── services/inventory_service.py
│   ├── utils/exporters.py
│   └── main.py
├── tests/test_inventory_service.py
├── exports/                 # reportes locales (ignorado en Git)
├── requirements.txt
├── .gitignore
└── README.md
```

## Git y GitHub: flujo de trabajo

### Fase 1 — repositorio y configuración

```bash
git init
git branch -M main
git add .gitignore README.md requirements.txt src tests
git commit -m "chore: inicializa estructura del sistema de inventario"
git remote add origin https://github.com/USUARIO/sistema-inventario.git
git push -u origin main
```

Crea ramas de trabajo desde `main`, por ejemplo:

```bash
git switch -c feature/categorias-productos
# implementar, probar y guardar cambios
git add src tests && git commit -m "feat: agrega gestion de categorias y productos"
git push -u origin feature/categorias-productos
```

Abre un Pull Request a `main`, revisa las pruebas y fusiona. Repite con `feature/kardex-reportes` y `test/documentacion`.

### Convención de commits

- `feat:` nueva funcionalidad.
- `fix:` corrección de un defecto.
- `test:` pruebas automatizadas.
- `docs:` documentación.
- `refactor:` reestructuración sin cambiar comportamiento.
- `chore:` mantenimiento/configuración.

No agregues la base SQLite, `.env`, entornos virtuales ni exportaciones generadas. Si accidentalmente se versionó un archivo, quitarlo del índice con `git rm --cached RUTA` y crear un commit correctivo.

## Mejoras de producción sugeridas

Antes de desplegar con varios usuarios, incorporar autenticación/autorización, auditoría de usuarios, copias de seguridad automáticas, política de moneda/impuestos, migraciones de esquema y una API o interfaz web. SQLite funciona bien para una pequeña instalación con escritura moderada; para concurrencia elevada conviene migrar a PostgreSQL.

## Ejecutar en GitHub Codespaces

1. Sube esta carpeta a un repositorio GitHub independiente llamado `sistema-inventario`.
2. En GitHub, abre **Code → Codespaces → Create codespace on main**.
3. Espera a que el entorno instale las dependencias y abre la terminal integrada.
4. Ejecuta:

```bash
python -m src.main
```

Para ejecutar las pruebas:

```bash
python -m unittest discover -s tests -v
```

El menú es interactivo: ejecútalo en la terminal de Codespaces, no como un paso de GitHub Actions. GitHub Actions ejecuta automáticamente las pruebas al hacer `push` o abrir un Pull Request.
