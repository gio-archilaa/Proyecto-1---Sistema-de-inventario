"""Sistema de inventario para pequeña empresa."""
