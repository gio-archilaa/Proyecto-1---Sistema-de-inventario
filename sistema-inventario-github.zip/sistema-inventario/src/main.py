"""Interfaz de consola del sistema de inventario."""
from __future__ import annotations

from pathlib import Path

from src.database.connection import Database
from src.services.inventory_service import InventoryService
from src.utils.exporters import export_csv, export_excel

ROOT = Path(__file__).resolve().parents[1]
EXPORT_DIR = ROOT / "exports"


def ask_int(prompt: str, *, minimum: int = 0) -> int:
    while True:
        try:
            value = int(input(prompt).strip())
            if value < minimum:
                raise ValueError
            return value
        except ValueError:
            print(f"Introduce un entero mayor o igual a {minimum}.")


def ask_float(prompt: str) -> float:
    while True:
        try:
            value = float(input(prompt).strip().replace(",", "."))
            if value < 0:
                raise ValueError
            return value
        except ValueError:
            print("Introduce un número válido mayor o igual a cero.")


def show_rows(rows: list[dict], *, limit: int = 30) -> None:
    if not rows:
        print("No hay registros para mostrar.")
        return
    for row in rows[:limit]:
        print(" | ".join(f"{key}: {value}" for key, value in row.items()))
    if len(rows) > limit:
        print(f"... {len(rows) - limit} registros adicionales.")


def choose_category(service: InventoryService) -> int:
    categories = service.list_categories()
    show_rows(categories)
    if not categories:
        raise ValueError("Primero debes crear una categoría.")
    category_id = ask_int("ID de categoría: ", minimum=1)
    if category_id not in {row["id"] for row in categories}:
        raise ValueError("ID de categoría no válido.")
    return category_id


def create_category(service: InventoryService) -> None:
    name = input("Nombre: ")
    description = input("Descripción: ")
    category_id = service.create_category(name, description)
    print(f"Categoría creada con ID {category_id}.")


def edit_category(service: InventoryService) -> None:
    show_rows(service.list_categories())
    category_id = ask_int("ID a editar: ", minimum=1)
    service.update_category(category_id, input("Nuevo nombre: "), input("Nueva descripción: "))
    print("Categoría actualizada.")


def create_product(service: InventoryService) -> None:
    print("Categorías disponibles:")
    category_id = choose_category(service)
    product_id = service.create_product(
        sku=input("SKU/código único: "), name=input("Nombre: "),
        description=input("Descripción: "), purchase_price=ask_float("Precio de compra: "),
        sale_price=ask_float("Precio de venta: "), minimum_stock=ask_int("Stock mínimo: "),
        category_id=category_id,
    )
    initial_stock = ask_int("Stock inicial (0 si no hay existencias): ")
    if initial_stock:
        service.register_movement(product_id, "ENTRADA", initial_stock, "Inventario inicial")
    print(f"Producto creado con ID {product_id}.")


def edit_product(service: InventoryService) -> None:
    show_rows(service.search_products())
    product_id = ask_int("ID de producto a editar: ", minimum=1)
    product = service.get_product(product_id)
    if not product:
        raise ValueError("Producto no encontrado.")
    print("Deja un campo vacío para conservar el valor actual.")
    def text_value(label: str, key: str) -> str:
        value = input(f"{label} [{product[key]}]: ").strip()
        return value or str(product[key])
    category_input = input(f"ID categoría [{product['category_id']}]: ").strip()
    service.update_product(
        product_id, sku=text_value("SKU", "sku"), name=text_value("Nombre", "name"),
        description=text_value("Descripción", "description"),
        purchase_price=ask_float(f"Precio compra [{product['purchase_price']}]: ")
            if input_confirm("¿Cambiar precio de compra? (s/N): ") else product["purchase_price"],
        sale_price=ask_float(f"Precio venta [{product['sale_price']}]: ")
            if input_confirm("¿Cambiar precio de venta? (s/N): ") else product["sale_price"],
        minimum_stock=ask_int(f"Stock mínimo [{product['minimum_stock']}]: ")
            if input_confirm("¿Cambiar stock mínimo? (s/N): ") else product["minimum_stock"],
        category_id=int(category_input) if category_input else product["category_id"],
    )
    print("Producto actualizado. El stock solo se modifica mediante movimientos.")


def input_confirm(prompt: str) -> bool:
    return input(prompt).strip().lower() in {"s", "si", "sí"}


def register_movement(service: InventoryService) -> None:
    show_rows(service.search_products())
    product_id = ask_int("ID del producto: ", minimum=1)
    movement_type = input("Tipo (E=entrada, S=salida): ").strip().upper()
    movement_type = {"E": "ENTRADA", "S": "SALIDA"}.get(movement_type, movement_type)
    quantity = ask_int("Cantidad: ", minimum=1)
    reason = input("Motivo/observación: ")
    movement_id = service.register_movement(product_id, movement_type, quantity, reason)
    print(f"Movimiento #{movement_id} registrado; stock actualizado.")


def search_products_menu(service: InventoryService) -> None:
    term = input("SKU o nombre parcial (vacío=todos): ").strip()
    category_text = input("ID de categoría (vacío=todas): ").strip()
    category_id = int(category_text) if category_text else None
    show_rows(service.search_products(term, category_id))


def show_inventory_report(service: InventoryService) -> None:
    rows = service.inventory_report()
    show_rows(rows)
    totals = service.inventory_totals()
    print(f"\nVALOR TOTAL A COSTO: {totals['total_cost_value']:.2f}")
    print(f"VALOR POTENCIAL DE VENTA: {totals['total_sale_value']:.2f}")


def search_movements_menu(service: InventoryService) -> None:
    product_text = input("ID de producto (vacío=todos): ").strip()
    start_date = input("Desde AAAA-MM-DD (vacío=todas): ").strip() or None
    end_date = input("Hasta AAAA-MM-DD (vacío=todas): ").strip() or None
    show_rows(service.list_movements(product_id=int(product_text) if product_text else None,
                                     start_date=start_date, end_date=end_date))


def export_reports(service: InventoryService) -> None:
    inventory = service.inventory_report()
    totals = service.inventory_totals()
    inventory_export = list(inventory)
    inventory_export.append({
        "sku": "", "name": "TOTAL INVENTARIO", "description": "", "purchase_price": "",
        "sale_price": "", "stock": "", "minimum_stock": "", "category_name": "",
        "cost_value": totals["total_cost_value"], "sale_value": totals["total_sale_value"],
    })
    low_stock = service.low_stock_report()
    movements = service.list_movements()
    EXPORT_DIR.mkdir(exist_ok=True)
    csv_path = export_csv(inventory_export, EXPORT_DIR / "inventario_general.csv")
    export_csv(low_stock, EXPORT_DIR / "stock_bajo.csv")
    export_csv(movements, EXPORT_DIR / "kardex.csv")
    excel_path = export_excel(
        {"Inventario": inventory_export, "Stock bajo": low_stock, "Kardex": movements},
        EXPORT_DIR / "reportes_inventario.xlsx",
    )
    print(f"Reportes exportados a:\n- {csv_path}\n- {excel_path}")


def menu() -> None:
    service = InventoryService(Database())
    actions = {
        "1": ("Crear categoría", lambda: create_category(service)),
        "2": ("Editar categoría", lambda: edit_category(service)),
        "3": ("Registrar producto", lambda: create_product(service)),
        "4": ("Buscar/listar productos", lambda: search_products_menu(service)),
        "5": ("Editar producto", lambda: edit_product(service)),
        "6": ("Desactivar producto", lambda: service.deactivate_product(ask_int("ID: ", minimum=1))),
        "7": ("Registrar entrada/salida (Kardex)", lambda: register_movement(service)),
        "8": ("Ver inventario valorizado", lambda: show_inventory_report(service)),
        "9": ("Ver alertas de stock bajo", lambda: show_rows(service.low_stock_report())),
        "10": ("Consultar Kardex por producto/fechas", lambda: search_movements_menu(service)),
        "11": ("Exportar CSV y Excel", lambda: export_reports(service)),
        "12": ("Listar categorías", lambda: show_rows(service.list_categories())),
    }
    while True:
        print("\n" + "=" * 58 + "\n SISTEMA DE GESTIÓN DE INVENTARIO\n" + "=" * 58)
        for key, (label, _) in actions.items():
            print(f"{key:>2}. {label}")
        print(" 0. Salir")
        option = input("Selecciona una opción: ").strip()
        if option == "0":
            print("Hasta pronto.")
            break
        action = actions.get(option)
        if not action:
            print("Opción no válida.")
            continue
        try:
            action[1]()
        except (ValueError, RuntimeError) as exc:
            print(f"No se pudo completar la operación: {exc}")
        except Exception as exc:  # última barrera para que la consola no se cierre
            print(f"Error inesperado ({type(exc).__name__}): {exc}")


if __name__ == "__main__":
    menu()
