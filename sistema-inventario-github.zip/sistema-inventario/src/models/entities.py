"""Entidades del dominio del inventario."""
from dataclasses import dataclass
from datetime import datetime
from typing import Literal

MovementType = Literal["ENTRADA", "SALIDA"]


@dataclass(frozen=True, slots=True)
class Categoria:
    id: int | None
    nombre: str
    descripcion: str = ""


@dataclass(frozen=True, slots=True)
class Producto:
    id: int | None
    sku: str
    nombre: str
    descripcion: str
    precio_compra: float
    precio_venta: float
    stock: int
    stock_minimo: int
    categoria_id: int
    activo: bool = True


@dataclass(frozen=True, slots=True)
class Movimiento:
    id: int | None
    producto_id: int
    tipo: MovementType
    cantidad: int
    motivo: str
    fecha: datetime | None = None
    stock_anterior: int | None = None
    stock_nuevo: int | None = None
