"""Acceso a datos: aquí viven las consultas SQL y nada de reglas de negocio."""
from __future__ import annotations

import sqlite3
from typing import Any


class InventoryRepository:
    def __init__(self, connection: sqlite3.Connection) -> None:
        self.conn = connection

    # Categorías
    def create_category(self, name: str, description: str) -> int:
        cursor = self.conn.execute(
            "INSERT INTO categories(name, description) VALUES (?, ?)", (name, description)
        )
        return int(cursor.lastrowid)

    def list_categories(self) -> list[dict[str, Any]]:
        rows = self.conn.execute("SELECT * FROM categories ORDER BY name COLLATE NOCASE").fetchall()
        return [dict(row) for row in rows]

    def update_category(self, category_id: int, name: str, description: str) -> None:
        cursor = self.conn.execute(
            "UPDATE categories SET name = ?, description = ? WHERE id = ?",
            (name, description, category_id),
        )
        if cursor.rowcount == 0:
            raise ValueError("La categoría indicada no existe.")

    # Productos
    def create_product(self, values: dict[str, Any]) -> int:
        cursor = self.conn.execute(
            """INSERT INTO products
            (sku, name, description, purchase_price, sale_price, stock, minimum_stock, category_id)
            VALUES (?, ?, ?, ?, ?, 0, ?, ?)""",
            (values["sku"], values["name"], values["description"], values["purchase_price"],
             values["sale_price"], values["minimum_stock"], values["category_id"]),
        )
        return int(cursor.lastrowid)

    def get_product(self, product_id: int, *, include_inactive: bool = False) -> dict[str, Any] | None:
        sql = "SELECT p.*, c.name AS category_name FROM products p JOIN categories c ON c.id=p.category_id WHERE p.id=?"
        params: tuple[Any, ...] = (product_id,)
        if not include_inactive:
            sql += " AND p.active=1"
        row = self.conn.execute(sql, params).fetchone()
        return dict(row) if row else None

    def update_product(self, product_id: int, values: dict[str, Any]) -> None:
        cursor = self.conn.execute(
            """UPDATE products SET sku=?, name=?, description=?, purchase_price=?, sale_price=?,
            minimum_stock=?, category_id=?, updated_at=strftime('%Y-%m-%dT%H:%M:%f','now')
            WHERE id=? AND active=1""",
            (values["sku"], values["name"], values["description"], values["purchase_price"],
             values["sale_price"], values["minimum_stock"], values["category_id"], product_id),
        )
        if cursor.rowcount == 0:
            raise ValueError("El producto no existe o está desactivado.")

    def deactivate_product(self, product_id: int) -> None:
        cursor = self.conn.execute(
            "UPDATE products SET active=0, updated_at=strftime('%Y-%m-%dT%H:%M:%f','now') WHERE id=? AND active=1",
            (product_id,),
        )
        if cursor.rowcount == 0:
            raise ValueError("El producto no existe o ya está desactivado.")

    def search_products(self, term: str = "", category_id: int | None = None) -> list[dict[str, Any]]:
        sql = """SELECT p.*, c.name AS category_name FROM products p
                 JOIN categories c ON c.id=p.category_id WHERE p.active=1"""
        params: list[Any] = []
        if term.strip():
            pattern = f"%{term.strip()}%"
            sql += " AND (p.sku LIKE ? OR p.name LIKE ?)"
            params.extend((pattern, pattern))
        if category_id is not None:
            sql += " AND p.category_id=?"
            params.append(category_id)
        sql += " ORDER BY p.name COLLATE NOCASE"
        return [dict(row) for row in self.conn.execute(sql, params).fetchall()]

    # Kardex
    def insert_movement(self, values: dict[str, Any]) -> int:
        cursor = self.conn.execute(
            """INSERT INTO movements(product_id, movement_type, quantity, reason,
            stock_before, stock_after) VALUES (?, ?, ?, ?, ?, ?)""",
            (values["product_id"], values["type"], values["quantity"], values["reason"],
             values["stock_before"], values["stock_after"]),
        )
        return int(cursor.lastrowid)

    def update_stock(self, product_id: int, new_stock: int) -> None:
        cursor = self.conn.execute(
            "UPDATE products SET stock=?, updated_at=strftime('%Y-%m-%dT%H:%M:%f','now') WHERE id=? AND active=1",
            (new_stock, product_id),
        )
        if cursor.rowcount == 0:
            raise ValueError("No se pudo actualizar el stock del producto.")

    def list_movements(self, *, product_id: int | None = None,
                       start_date: str | None = None, end_date: str | None = None) -> list[dict[str, Any]]:
        sql = """SELECT m.*, p.sku, p.name AS product_name FROM movements m
                 JOIN products p ON p.id=m.product_id WHERE 1=1"""
        params: list[Any] = []
        if product_id is not None:
            sql += " AND m.product_id=?"
            params.append(product_id)
        if start_date:
            sql += " AND date(m.occurred_at)>=date(?)"
            params.append(start_date)
        if end_date:
            sql += " AND date(m.occurred_at)<=date(?)"
            params.append(end_date)
        sql += " ORDER BY m.occurred_at DESC, m.id DESC"
        return [dict(row) for row in self.conn.execute(sql, params).fetchall()]

    # Reportes
    def inventory_report(self) -> list[dict[str, Any]]:
        rows = self.conn.execute(
            """SELECT p.sku,p.name,p.description,p.purchase_price,p.sale_price,p.stock,
            p.minimum_stock,c.name AS category_name,
            p.purchase_price*p.stock AS cost_value,p.sale_price*p.stock AS sale_value
            FROM products p JOIN categories c ON c.id=p.category_id
            WHERE p.active=1 ORDER BY p.name COLLATE NOCASE"""
        ).fetchall()
        return [dict(row) for row in rows]

    def low_stock_report(self) -> list[dict[str, Any]]:
        rows = self.conn.execute(
            """SELECT p.sku,p.name,p.stock,p.minimum_stock,c.name AS category_name
            FROM products p JOIN categories c ON c.id=p.category_id
            WHERE p.active=1 AND p.stock<=p.minimum_stock ORDER BY p.stock,p.name"""
        ).fetchall()
        return [dict(row) for row in rows]
