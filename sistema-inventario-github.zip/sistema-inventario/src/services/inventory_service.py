"""Casos de uso y validaciones del sistema de inventario."""
from __future__ import annotations

import sqlite3
import math
from datetime import date
from typing import Any

from src.database.connection import Database
from src.repositories.inventory_repository import InventoryRepository


class InventoryService:
    """Coordina repositorios y reglas de negocio; el stock solo cambia vía Kardex."""

    def __init__(self, database: Database) -> None:
        self.database = database
        self.database.initialize()

    @staticmethod
    def _text(value: str, field: str) -> str:
        value = str(value).strip()
        if not value:
            raise ValueError(f"El campo {field} es obligatorio.")
        return value

    @staticmethod
    def _nonnegative_number(value: float, field: str) -> float:
        try:
            number = float(value)
        except (TypeError, ValueError) as exc:
            raise ValueError(f"{field} debe ser un número válido.") from exc
        if not math.isfinite(number):
            raise ValueError(f"{field} debe ser un número finito.")
        if number < 0:
            raise ValueError(f"{field} no puede ser negativo.")
        return number

    @staticmethod
    def _nonnegative_int(value: int, field: str) -> int:
        try:
            numeric = float(value)
        except (TypeError, ValueError) as exc:
            raise ValueError(f"{field} debe ser un entero mayor o igual a cero.") from exc
        if isinstance(value, bool) or not math.isfinite(numeric) or not numeric.is_integer() or numeric < 0:
            raise ValueError(f"{field} debe ser un entero mayor o igual a cero.")
        return int(numeric)

    def create_category(self, name: str, description: str = "") -> int:
        name = self._text(name, "nombre de categoría")
        with self.database.session(write=True) as conn:
            try:
                return InventoryRepository(conn).create_category(name, description.strip())
            except sqlite3.IntegrityError as exc:
                raise ValueError("Ya existe una categoría con ese nombre.") from exc

    def list_categories(self) -> list[dict[str, Any]]:
        with self.database.session() as conn:
            return InventoryRepository(conn).list_categories()

    def update_category(self, category_id: int, name: str, description: str = "") -> None:
        name = self._text(name, "nombre de categoría")
        with self.database.session(write=True) as conn:
            try:
                InventoryRepository(conn).update_category(category_id, name, description.strip())
            except sqlite3.IntegrityError as exc:
                raise ValueError("Ya existe una categoría con ese nombre.") from exc

    def create_product(self, *, sku: str, name: str, description: str = "",
                       purchase_price: float, sale_price: float, minimum_stock: int,
                       category_id: int) -> int:
        values = {
            "sku": self._text(sku, "SKU").upper(), "name": self._text(name, "nombre"),
            "description": description.strip(),
            "purchase_price": self._nonnegative_number(purchase_price, "precio de compra"),
            "sale_price": self._nonnegative_number(sale_price, "precio de venta"),
            "minimum_stock": self._nonnegative_int(minimum_stock, "stock mínimo"),
            "category_id": self._nonnegative_int(category_id, "categoría"),
        }
        with self.database.session(write=True) as conn:
            try:
                return InventoryRepository(conn).create_product(values)
            except sqlite3.IntegrityError as exc:
                if "UNIQUE" in str(exc).upper():
                    raise ValueError("El SKU ya está registrado.") from exc
                raise ValueError("Categoría inválida o datos que incumplen las reglas de la base de datos.") from exc

    def update_product(self, product_id: int, *, sku: str, name: str, description: str = "",
                       purchase_price: float, sale_price: float, minimum_stock: int,
                       category_id: int) -> None:
        values = {
            "sku": self._text(sku, "SKU").upper(), "name": self._text(name, "nombre"),
            "description": description.strip(),
            "purchase_price": self._nonnegative_number(purchase_price, "precio de compra"),
            "sale_price": self._nonnegative_number(sale_price, "precio de venta"),
            "minimum_stock": self._nonnegative_int(minimum_stock, "stock mínimo"),
            "category_id": self._nonnegative_int(category_id, "categoría"),
        }
        with self.database.session(write=True) as conn:
            try:
                InventoryRepository(conn).update_product(product_id, values)
            except sqlite3.IntegrityError as exc:
                if "UNIQUE" in str(exc).upper():
                    raise ValueError("El SKU ya está registrado.") from exc
                raise ValueError("Categoría inválida o datos no permitidos.") from exc

    def deactivate_product(self, product_id: int) -> None:
        with self.database.session(write=True) as conn:
            InventoryRepository(conn).deactivate_product(product_id)

    def get_product(self, product_id: int) -> dict[str, Any] | None:
        with self.database.session() as conn:
            return InventoryRepository(conn).get_product(product_id)

    def search_products(self, term: str = "", category_id: int | None = None) -> list[dict[str, Any]]:
        with self.database.session() as conn:
            return InventoryRepository(conn).search_products(term, category_id)

    def register_movement(self, product_id: int, movement_type: str, quantity: int, reason: str) -> int:
        movement_type = movement_type.strip().upper()
        if movement_type not in {"ENTRADA", "SALIDA"}:
            raise ValueError("El tipo de movimiento debe ser ENTRADA o SALIDA.")
        quantity = self._nonnegative_int(quantity, "cantidad")
        if quantity == 0:
            raise ValueError("La cantidad debe ser mayor que cero.")
        reason = self._text(reason, "motivo")
        # BEGIN IMMEDIATE serializa escritores: evita ventas concurrentes sobre el mismo stock.
        with self.database.session(write=True) as conn:
            repo = InventoryRepository(conn)
            product = repo.get_product(product_id)
            if product is None:
                raise ValueError("Producto inexistente o desactivado.")
            before = int(product["stock"])
            after = before + quantity if movement_type == "ENTRADA" else before - quantity
            if after < 0:
                raise ValueError(f"Stock insuficiente. Disponible: {before}; solicitado: {quantity}.")
            movement_id = repo.insert_movement({
                "product_id": product_id, "type": movement_type, "quantity": quantity,
                "reason": reason, "stock_before": before, "stock_after": after,
            })
            repo.update_stock(product_id, after)
            return movement_id

    def list_movements(self, *, product_id: int | None = None,
                       start_date: str | None = None, end_date: str | None = None) -> list[dict[str, Any]]:
        for value in (start_date, end_date):
            if value:
                try:
                    date.fromisoformat(value)
                except ValueError as exc:
                    raise ValueError("Las fechas deben usar el formato AAAA-MM-DD.") from exc
        if start_date and end_date and start_date > end_date:
            raise ValueError("La fecha inicial no puede ser posterior a la fecha final.")
        with self.database.session() as conn:
            return InventoryRepository(conn).list_movements(
                product_id=product_id, start_date=start_date, end_date=end_date
            )

    def inventory_report(self) -> list[dict[str, Any]]:
        with self.database.session() as conn:
            return InventoryRepository(conn).inventory_report()

    def low_stock_report(self) -> list[dict[str, Any]]:
        with self.database.session() as conn:
            return InventoryRepository(conn).low_stock_report()

    def inventory_totals(self) -> dict[str, float]:
        """Calcula valorización agregada del inventario activo."""
        rows = self.inventory_report()
        return {
            "total_cost_value": sum(float(row["cost_value"]) for row in rows),
            "total_sale_value": sum(float(row["sale_value"]) for row in rows),
        }
