"""Exportación de reportes a CSV y Excel."""
from __future__ import annotations

import csv
from pathlib import Path
from typing import Any, Iterable


def export_csv(rows: Iterable[dict[str, Any]], path: str | Path) -> Path:
    """Escribe una colección de diccionarios en CSV UTF-8 con BOM (Excel-friendly)."""
    rows = list(rows)
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = list(rows[0].keys()) if rows else []
    with destination.open("w", newline="", encoding="utf-8-sig") as file:
        if fieldnames:
            writer = csv.DictWriter(file, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(rows)
    return destination


def export_excel(sheets: dict[str, list[dict[str, Any]]], path: str | Path) -> Path:
    """Genera un libro .xlsx; openpyxl se declara en requirements.txt."""
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Font, PatternFill
        from openpyxl.utils import get_column_letter
    except ImportError as exc:  # pragma: no cover - depende del entorno
        raise RuntimeError("Instala openpyxl para exportar Excel: pip install openpyxl") from exc

    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    workbook = Workbook()
    workbook.remove(workbook.active)
    for sheet_name, rows in sheets.items():
        sheet = workbook.create_sheet(sheet_name[:31])
        fields = list(rows[0].keys()) if rows else []
        if not fields:
            sheet.append(["Sin datos"])
            continue
        sheet.append(fields)
        for cell in sheet[1]:
            cell.font = Font(bold=True, color="FFFFFF")
            cell.fill = PatternFill("solid", fgColor="24476B")
        for row in rows:
            sheet.append([row.get(field) for field in fields])
        sheet.freeze_panes = "A2"
        sheet.auto_filter.ref = sheet.dimensions
        for column_index, field in enumerate(fields, start=1):
            max_length = max(len(str(field)), *(len(str(row.get(field, ""))) for row in rows))
            sheet.column_dimensions[get_column_letter(column_index)].width = min(max_length + 2, 36)
    workbook.save(destination)
    return destination
