"""Pruebas de reglas críticas con una base SQLite temporal."""
import tempfile
import unittest
from pathlib import Path

from src.database.connection import Database
from src.services.inventory_service import InventoryService
from src.utils.exporters import export_csv, export_excel


class InventoryServiceTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp_dir = tempfile.TemporaryDirectory()
        db = Database(Path(self.temp_dir.name) / "test.db")
        self.service = InventoryService(db)
        self.category_id = self.service.create_category("Accesorios")
        self.product_id = self.service.create_product(
            sku="CAB-001", name="Cable USB", purchase_price=2.5, sale_price=5.0,
            minimum_stock=3, category_id=self.category_id,
        )

    def tearDown(self) -> None:
        self.temp_dir.cleanup()

    def test_movement_updates_stock_and_kardex(self) -> None:
        self.service.register_movement(self.product_id, "ENTRADA", 10, "Compra")
        self.service.register_movement(self.product_id, "SALIDA", 4, "Venta")
        product = self.service.get_product(self.product_id)
        movements = self.service.list_movements(product_id=self.product_id)
        self.assertEqual(product["stock"], 6)
        self.assertEqual(len(movements), 2)
        self.assertEqual(movements[0]["stock_after"], 6)

    def test_insufficient_stock_rolls_back(self) -> None:
        with self.assertRaisesRegex(ValueError, "Stock insuficiente"):
            self.service.register_movement(self.product_id, "SALIDA", 1, "Venta")
        self.assertEqual(self.service.get_product(self.product_id)["stock"], 0)
        self.assertEqual(self.service.list_movements(product_id=self.product_id), [])

    def test_duplicate_sku_is_rejected(self) -> None:
        with self.assertRaisesRegex(ValueError, "SKU"):
            self.service.create_product(
                sku="cab-001", name="Otro", purchase_price=1, sale_price=2,
                minimum_stock=0, category_id=self.category_id,
            )

    def test_low_stock_includes_equal_minimum(self) -> None:
        self.service.register_movement(self.product_id, "ENTRADA", 3, "Reposición")
        self.assertEqual(len(self.service.low_stock_report()), 1)

    def test_deactivation_preserves_history(self) -> None:
        self.service.register_movement(self.product_id, "ENTRADA", 2, "Compra")
        self.service.deactivate_product(self.product_id)
        self.assertIsNone(self.service.get_product(self.product_id))
        self.assertEqual(len(self.service.list_movements(product_id=self.product_id)), 1)

    def test_invalid_non_finite_price_is_rejected(self) -> None:
        with self.assertRaisesRegex(ValueError, "finito"):
            self.service.create_product(
                sku="NAN-1", name="Inválido", purchase_price=float("nan"), sale_price=2,
                minimum_stock=0, category_id=self.category_id,
            )

    def test_inventory_totals(self) -> None:
        self.service.register_movement(self.product_id, "ENTRADA", 4, "Compra")
        totals = self.service.inventory_totals()
        self.assertEqual(totals["total_cost_value"], 10.0)
        self.assertEqual(totals["total_sale_value"], 20.0)

    def test_csv_and_excel_exports(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            rows = self.service.inventory_report()
            csv_path = export_csv(rows, Path(directory) / "inventory.csv")
            xlsx_path = export_excel({"Inventario": rows}, Path(directory) / "inventory.xlsx")
            self.assertTrue(csv_path.exists())
            self.assertTrue(xlsx_path.exists())
            self.assertGreater(csv_path.stat().st_size, 0)
            self.assertGreater(xlsx_path.stat().st_size, 0)


if __name__ == "__main__":
    unittest.main()
